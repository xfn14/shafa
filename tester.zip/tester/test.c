#include <stdio.h>
#include <stdlib.h>
#include "fsize.h"

void main(){
    split("../resources/aaa.txt");
}

int split (char filename[]) {
    unsigned int total;
    unsigned int n_blocks;
    unsigned int size_of_last_block, block_size;
    int bytesRead;   
    FILE *exsistingFile;
    exsistingFile = fopen(filename,"rb"); 
    char newFileName[20]= "exeploaaa.txt";
    int i = 1, flag = 1;
    
    block_size = 2048;
    fseek(exsistingFile, 0L, SEEK_END);
    total = ftell(exsistingFile);
    fseek(exsistingFile, 0L, SEEK_SET);

    // block_size = 2048;
    // n_blocks = fsize(exsistingFile, NULL, &block_size, &size_of_last_block);
    // total = (n_blocks-1) * block_size + size_of_last_block;

    do
    {   
        FILE *outputFile = fopen(newFileName,"wb");

        if ( !outputFile )
        {
            printf( "File %s cannot be opened for writing\n", filename );
            return -1; 
        }

        int workSize = total;
        printf("worksize = %d bytes\n", workSize);
        while (workSize)
        {
            printf("entrei\n");
            
            int chunkSize = workSize > block_size ? block_size : workSize;
            printf ("chunksize = %d bytes\n", chunkSize);
            char *buffer = malloc(sizeof(char)*chunkSize);

            bytesRead = fread(buffer, sizeof(char), chunkSize, exsistingFile);
            printf ("%s", buffer);
            printf ("\n");
            printf ("bytesRead = %d bytes\n", bytesRead);
            workSize -= bytesRead;

            if (bytesRead == 0)
            {
                printf("The reading has finished or the file has no data inside\n");
                return 0;
            } 
            
            printf ("iteração nº %d\n", i);
            printf ("-------------------------------------\n");
            i++;

            fwrite(buffer,sizeof(char),bytesRead,outputFile);
        }

        fclose(outputFile);
        flag = 0;

} while ( bytesRead > 0 && flag);

fclose(exsistingFile);
printf("ACABOU\n");
}
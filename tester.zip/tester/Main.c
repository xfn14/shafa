#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include "c_array.h"
#include "fsize.h"
#include "d_array.h"
#include "d_matrix.h"

#define BUFFER 200
#define CODE_MAX_SIZE 8

/*
 * [110, 100, 001]
 *
 * [
 * 1100000000000000, 1000000000000000, 0010000000000000,
 * 0110000000000000, 0100000000000000, 0001000000000000,
 * 0011000000000000, 0010000000000000, 0000100000000000
 */

//void formatCodes(unsigned char **codes, unsigned int n_codes, D_Array out_codes){
//    out_codes[0] = (unsigned char*) "110";
//    printf("%s", out_codes[0]);
//    for(int i = 0; i < n_codes; i++){
//        for(int offset = 0; offset < 8; offset++){
//            unsigned char *temp_char = malloc(sizeof(unsigned char)*16);
//            if(offset != 0){
//                for(int j = 0; j < offset; j++){
//                    strcat((char*) temp_char, "0");
//                    printf("%s\n", temp_char);
//                }
//            }
//            strcat((char*) temp_char, (char*) codes[i]);
//            int len = strlen((char*) temp_char);
//            for(int p = 0; p < (16-len); p++){
//                strcat((char*) temp_char, "0");
//            }
//            strcat((char*) out_codes[i+(n_codes*offset)], (char*) temp_char);
//        }
//    }
//}

//char*[] formatCodes(unsigned char *codes[], unsigned int n_codes){
//    unsigned char *out_codes[] = malloc(sizeof(char)*n_codes);
//    int crt = 0;
//    for(int i = 0; i < n_codes; i++){
//        char temp_char[] = malloc(sizeof(char)*strlen(codes[i]));
//        strcat(temp_char, codes[i]);
//        for(int j = 0; j < (8 - strlen(temp_char)); j++){
//            strcat(temp_char, "0");
//        }
//        strcat(temp_char, ".00000000");
//        strcat(out_codes, &temp_char);
//        free(temp_char);
//    }
//    return &out_codes;
//}

//void codecat(unsigned char* code, unsigned char* cat){
//    int i = 0; int j = 0;
//    while(code[i] != '\0')
//        i++;
//    while(cat[j] != '\0'){
//        code[i+j] = cat[j];
//        j++;
//    }
//}

int reverse(int n){
    int rev = 0, remainder;
    while(n != 0){
        remainder = n % 10;
        rev = rev * 10 + remainder;
        n /= 10;
    }
    return rev;
}

long readIntInCod(FILE *fp){
    int decimal = 0;
    char crt_char = '0';
    long finalN = 0;
    while(crt_char != '@'){
        fread(&crt_char, sizeof(char), 1, fp); decimal++;
        if(crt_char != '@'){
            int crt_int = atoi(&crt_char);
//            printf("%d", crt_int);
            finalN = (long) pow(10, decimal)*crt_int + finalN;
        }
    }
    return reverse(finalN/10);
}

void readCodFile(char *filename, codes_lists_struct *codes_lists){
    FILE *in;
    in = fopen(filename, "rb");

    char normal_rle;
    fseek(in, 1, SEEK_SET);
    fread(&normal_rle, sizeof(char), 1, in);
//    printf("%c\n", normal_rle);
    int chars_read = 3;
    fseek(in, chars_read, SEEK_SET);

    long n_blocks = readIntInCod(in);
//    printf("n_blocks: %ld\n", n_blocks);

    for(int i = 0; i < n_blocks; i++){
        code_list_struct block_codes;
        initList(&block_codes);
        long block_size = readIntInCod(in);
        setListBlockSize(&block_codes, block_size);

        unsigned char symb = 0;
        unsigned char crt_char = 0;
        D_Array crt_code;
        initArray(&crt_code, 3);
        while(crt_char != '@'){
            fread(&crt_char, sizeof(unsigned char), 1, in);
            if(crt_char == ';'){
                if(crt_code.used != 0){
                    for(int j = 0; j < 8; j++){
                        code_struct act_code;
                        initCode(&act_code);
                        setCodeSymb(&act_code, symb);
                        setCodeOffset(&act_code, j);

                        D_Array offset_code;
                        initArray(&offset_code, 5);
                        // Make offset
                        if(j != 0){
                            for(int p = 0; p < j; p++){
                                insertArray(&offset_code, '0');
                            }
                        }
                        // Put actual code
                        for(int p = 0; p < crt_code.used; p++){
                            insertArray(&offset_code, crt_code.array[p]);
                        }

                        if(offset_code.used > 7){
                            setCodeIndex(&act_code, 1);
                            setCodeNext(&act_code, offset_code.used-8);
                        }else{
                            setCodeIndex(&act_code, 0);
                            setCodeNext(&act_code, offset_code.used);
                        }

                        // Add the bits until 16bit code
                        for(int p = offset_code.used; p < 16; p++){
                            insertArray(&offset_code, '0');
                        }

                        setCode(&act_code, offset_code);
                        insertCodeList(&block_codes, act_code);
                        clearArray(&offset_code);
                    }
                    clearArray(&crt_code);
                }
                symb++;
            }else{
                if(crt_char != '@'){
                    insertArray(&crt_code, crt_char);
                }
            }
        }
        insertCodesLists(codes_lists, block_codes);
        freeArray(&crt_code);
    }

    fclose(in);

//    printCodesLists(codes_lists);
}

void binary_encoding(char *in_file, codes_lists_struct *codes_lists, D_Matrix_List *out_bytes) {
    FILE *in;
    in = fopen(in_file, "rb");
    fseek(in, 0, SEEK_SET);

    for (int i = 0; i < codes_lists->len; i++) {
        D_Matrix coded_bytes; // bytes for block
        initMatrix(&coded_bytes);

        code_list_struct crt_code_list = codes_lists->lists[i];
        unsigned char *crt_block_buffer = malloc(crt_code_list.block_size * sizeof(unsigned char));
        fread(crt_block_buffer, sizeof(unsigned char), crt_code_list.block_size, in);

        D_Array crt_byte;
        initArray(&crt_byte, 8);
        clear_byte(&crt_byte);

        code_struct code_to_use;
        initCode(&code_to_use);
        int offset = 0;
        for(int j = 0; j < crt_code_list.block_size; j++){
            unsigned char crt_symb = crt_block_buffer[j];
            getSymbCode(&crt_code_list, crt_symb, offset, &code_to_use);
            or_opp(&crt_byte, &code_to_use.code, 0);
            if(code_to_use.index == 1){
                addLineMatrix(&coded_bytes, crt_byte);
                clear_byte(&crt_byte);
                or_opp(&crt_byte, &code_to_use.code, 1);
            }
            offset = code_to_use.next;

            if(j == crt_code_list.block_size-1){
                addLineMatrix(&coded_bytes, crt_byte);
            }
        }
        insertMatrixInList(out_bytes, coded_bytes);
    }
    fclose(in);
}

//void convertToChar(int binaryChar[],int length)
//{
//    int multiplier = 0;
//    int i;
//    int sum = 0;
//    for(i = length - 1; i>=0; i--) {
//        sum += (binaryChar[i]*(1 << multiplier++));
//    }
//    for(i=length;i>=0;i++)
//    {
//        sum = sum + (binaryChar[i]*pow(2,multiplier));
//        multiplier = multiplier + 1;
//    }
//    printf("\nThe character is: %c",sum);
//}

unsigned char byte_to_char(D_Array *arr){
    int crt = 0, res = 0;
    for(int i = arr->used-1; i >= 0; i--){
//        res += (arr->array[i]*(1<<crt++));
        res += (int) pow(2, crt) * (arr->array[i] == '1' ? 1 : 0);
        crt++;
    }
    return
    (unsigned char) res;
}

void write_codes_in_file(char *out_file, D_Matrix_List *coded_bytes){
    FILE *out;
    out = fopen(out_file, "wb+");

    fprintf(out, "@%d@", coded_bytes->len);
//    fwrite(&coded_bytes->len ,sizeof(int),2, out_files);

    for(int i = 0; i < coded_bytes->len; i++){
        D_Matrix crt_matrix = coded_bytes->list[i];
        fprintf(out, "%d@", crt_matrix.len);
        for(int j = 0; j < crt_matrix.len; j++){
            unsigned char crt_byte = 0;
            crt_byte = byte_to_char(&crt_matrix.arr[j]);
            fprintf(out, "%c", crt_byte);
//            fwrite(crt_matrix.arr[i].array, crt_matrix.arr[i].used, sizeof(unsigned char), out_files);
        }
        if(i != coded_bytes->len-1) fprintf(out, "@");
    }

    fclose(out);
}


int main(){
    clock_t start_time = clock();

    codes_lists_struct codes_list;
    initCodesLists(&codes_list);
    readCodFile("../resources/aaa.txt.cod", &codes_list);
    printCodesLists(&codes_list);

    printf("\n\n\n");

    D_Matrix_List out_bytes;
    initMatrixList(&out_bytes);
    binary_encoding("../resources/aaa.txt", &codes_list, &out_bytes);
    printMatrixList(&out_bytes);

    write_codes_in_file("out.shaf", &out_bytes);

//    D_Array crt_byte;
//    initByte(&crt_byte);
//    clear_byte(&crt_byte);
//    or_opp(&crt_byte, codes_list.lists[0].codes[0].code,0);
//    or_opp(&crt_byte, codes_list.lists[0].codes[1].code,0);

//    print_array(&codes_list.lists[0].codes[0].code, 0);
////    printf("%d %d\n", codes_list.lists[0].codes[0].code.used, codes_list.lists[0].codes[1].code.used);
//    printf("\n");
//    print_array(&codes_list.lists[0].codes[1].code, 0);
//    printf("\n");
//    print_array(&crt_byte, 0);



//    code_struct crt_code;
//    initCode(&crt_code);
//    crt_code = getSymbCode(&codes_list.lists[0], 'a', 0);
//    printCode(&crt_code);



//    code_struct code1;
//    initCode(&code1);
//    setCodeSymb(&code1, 'a');
//    D_Array code1_arr;
//    initArray(&code1_arr, 4);
//    insertArray(&code1_arr, '0');
//    insertArray(&code1_arr, '0');
//    insertArray(&code1_arr, '1');
//    setCode(&code1, code1_arr);
//
//    code_struct code2;
//    initCode(&code2);
//    setCodeSymb(&code2, 'b');
//    D_Array code2_arr;
//    initArray(&code2_arr, 4);
//    insertArray(&code2_arr, '1');
//    insertArray(&code2_arr, '0');
//    insertArray(&code2_arr, '0');
//    setCode(&code2, code2_arr);
//
//    code_struct code3;
//    initCode(&code3);
//    setCodeSymb(&code3, 'c');
//    D_Array code3_arr;
//    initArray(&code3_arr, 4);
//    insertArray(&code3_arr, '0');
//    insertArray(&code3_arr, '1');
//    insertArray(&code3_arr, '0');
//    setCode(&code3, code3_arr);
//
//    code_struct code4;
//    initCode(&code4);
//    setCodeSymb(&code4, 'd');
//    D_Array code4_arr;
//    initArray(&code4_arr, 4);
//    insertArray(&code4_arr, '1');
//    insertArray(&code4_arr, '1');
//    insertArray(&code4_arr, '1');
//    setCode(&code4, code4_arr);
//
//    code_list_struct code_list;
//    initList(&code_list);
//    insertCodeList(&code_list, code1);
//    insertCodeList(&code_list, code2);
//    insertCodeList(&code_list, code3);
//    insertCodeList(&code_list, code4);
//
//    code_list_struct code_list2;
//    initList(&code_list2);
//    insertCodeList(&code_list2, code1);
//    insertCodeList(&code_list2, code2);
//    insertCodeList(&code_list2, code3);
//    insertCodeList(&code_list2, code4);
//
//    codes_lists_struct codes_lists;
//    initCodesLists(&codes_lists);
//    insertCodesLists(&codes_lists, code_list); // block 1 codes
//    insertCodesLists(&codes_lists, code_list2); // block 2 codes
//
//    printCodesLists(&codes_lists);



//    unsigned char **codes = calloc(3, sizeof(unsigned char**));
//    codes[0] = (unsigned char*) "110";
//    codes[1] = (unsigned char*) "001";
//    codes[2] = (unsigned char*) "111";

//    codecat(codes[0], codes[1]);



//    unsigned long long total;
//    long long n_blocks;
//    unsigned long size_of_last_block, block_size;
//    FILE *out_files = fopen("../resources/aaa.txt.cod", "rb");
//    block_size = 2048;
//    n_blocks = fsize(out_files, NULL, &block_size, &size_of_last_block);
//    total = (n_blocks-1)*block_size+size_of_last_block;
//    unsigned char *temp_buffer = malloc(sizeof(unsigned char)*block_size);
//    fread(temp_buffer, sizeof(unsigned char), block_size, out_files);
//    printf("%s\n", temp_buffer);
//    printf("%llu %lld %lu %lu\n", total, n_blocks, block_size, size_of_last_block);

//    printf("%s", codes[0]);
//
//    int n_codes = 3;
//
//    unsigned char **out_codes = calloc(n_codes*8, sizeof(char**));
//    formatCodes(codes, n_codes, out_codes);

//    for(int i = 0; i < n_codes*8; i++){
//        printf("%s\n", out_codes[i]);
//    }

    clock_t stop_time = clock();
    double elapsed = (double)(stop_time-start_time)/CLOCKS_PER_SEC*1000;
    printf("\n\n\n%fms\n", elapsed);
    return 0;
}

//char*[] binary_coding(unsigned char *symbols[], unsigned int n_symbols, unsigned char *codes[], unsigned int index[], unsigned char next[]){
//    unsigned char *coded_sequence[];
//    int offset = 0, ind_in = 0, ind_out = 0;
//    while(ind_in < n_symbols){
//        char symbol = symbols[ind_in] + offset;
//        int n_bytes_in_code = index[symbol];
//        char code = codes[symbol];
//        int ind_code = 0;
//        while (ind_code <= n_bytes_in_code){
//            coded_sequence[ind_out] = coded_sequence[ind_out]|code[ind_code];
//            if(ind_code < n_bytes_in_code){
//                ind_out++; ind_code++;
//            }
//        }
//        offset = next[symbol];
//        ind_in = ind_in + 1;
//    }
//    return coded_sequence;
//}

//int code_max_size(unsigned char *codes[], int n_symbols){
//    int i = 0, max = 0;
//    while(i < n_symbols){
//        if(max < strlen(codes[i])) max = strlen(codes[i]);
//        i++;
//    }
//    return max;
//}

// unsigned char* readCodFile(FILE *fp_in, unsigned char *filename);

// int test(char *codes[]){
//     printf("%x %x %x", codes[0], codes[1], codes[0][0]|codes[0][1]);
// }

// void formatCodes(unsigned char **codes, unsigned int n_codes, unsigned char **out_codes){
//     for(int i = 0; i < n_codes; i+=2){
//         unsigned char *temp_code = malloc(sizeof(unsigned char));
//         temp_code = (unsigned char*) codes[0];
//         printf("%s", temp_code);
//         for(int j = strlen(temp_code); j < 8; j++){
//             strcat(temp_code, "0");
//             printf("%s", temp_code);
//         }
//     }
//     for(int i = 0; i < n_codes; i++){
//
//     }
    
//     int crt = 0;
//     for(int i = 0; i < n_codes; i++){
//         char temp_char[] = "";
//         printf("%s", temp_char);
//         strcat(temp_char, codes[i]);
//         for(int j = 0; j < (8 - strlen(temp_char)); j++){
//             strcat(temp_char, "0");
//         }
//         strcat(temp_char, ".00000000");
//         strcat(out_codes[i], temp_char);
//     }
// }

// void encode(char *symbols_in, unsigned int n_symbols, unsigned char **codes, char *encoded_out){
//     char *symbols;
//     char *encoded;

//     symbols = *symbols_in;
//     encoded = *encoded;
    
//     for(int i = 0; i < n_symbols; i++){

//     }
// }

//int main(){
//

//    unsigned int n_codes = 2;
//    uint_fast16_t *codes = malloc(sizeof(uint_fast16_t)*n_codes);
//    codes[0] = 110;
//    printf("%lu %lu", codes[0], sizeof(codes[0]));

    
    // unsigned char **formated_codes = calloc(n_codes, sizeof(char**));
    // printf("%c\n", temp_symb);
//    unsigned int n_codes = 2;
//    unsigned char codes[n_codes][8];
//    unsigned char out_codes[n_codes*2*7][8];


//    unsigned char **codes = (unsigned char **) calloc(n_codes, sizeof(char**));
//    unsigned char **out_codes = (unsigned char **) calloc(n_codes*2*7, sizeof(char**));
//    strcat(codes[0], "100"); strcat(codes[1], "001");

//    unsigned int *codes = malloc(n_codes*sizeof(unsigned int));
//    codes[0] = 110|001;
//    printf("%x", codes[0]);

//    formatCodes(codes, n_codes, out_codes);

//    int temp, temp2; char *ptr, *ptr2;
//    temp = strtol(codes[0], &ptr, 2);
//    temp2 = strtol(codes[1], &ptr, 2);
//    printf("%d", temp);

    // formatCodes(codes, n_codes, formated_codes);

    //test(code);
    
    // unsigned char *out_codes[] = NULL;
    // formatCodes(code, n_codes, out_codes);





    // unsigned char b1 = 54, b2 = 70;
    // printf("%x %x %x\n", b1, b2, b1|b2);




    // FILE *fp;
    // readCodFile(fp, "../resources/aaa.txt.cod");






    // char result = or_bin('30', '40');
    // printf("%d\n", result);

    // aaabb 00011011 0
    // char buffer[BUFFER];
    // FILE *ptr;
    // ptr = fopen("../resources/aaa.txt.shaf", "rb");
    // fread(buffer, sizeof(buffer), 1, ptr);
    // buffer[1] = 27;
    // for(int i = 0; i < BUFFER; i++)
    //     printf("%x ", buffer[i]);

    // for(int i = 0; i < 3; i++){
    //     printf("\n");
    // }

    // char buffer2[BUFFER];
    // FILE *ptr2;
    // ptr2 = fopen("../resources/aaa.txt.cod", "rb");
    // fread(buffer2, sizeof(buffer2), 1, ptr2);
    // for(int i = 0; i < BUFFER; i++)
    //     printf("%08x ", buffer2[i]);

    // printf("\n");

    // FILE *write_ptr;
    // write_ptr = fopen("test.bin", "wb+");
    // fwrite(buffer, 8, 1, write_ptr);
//    return 0;
//}

// unsigned char* readCodFile(FILE *fp_in, unsigned char *filename){
//     unsigned char *codes, *temp_buffer;
//     unsigned long long total;

//     FILE *fp;
//     if(filename == NULL || *filename == 0){
//         fp = fp_in;
//     }else{
//         fp = fopen(filename, "rb");
//         if(fp == NULL) return NULL;
//     }

//     fseek(fp, 0L, SEEK_END);
//     total = ftell(fp);
//     fseek(fp, 0L, SEEK_SET);

//     temp_buffer = malloc(sizeof(unsigned char) * total);

//     fread(temp_buffer, sizeof(temp_buffer)*total, 1, fp);
//     for(int i = 0; i < total; i++){
//         printf("%d ", temp_buffer[i]);
//     }

//     // N(78); R(82)
//     // TODO RLE 
//     // if(temp_buffer[1] = 82){

//     return codes;
// }

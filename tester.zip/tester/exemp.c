//
// Created by andreubita on 27/12/20.
//

#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *in, *out;
    in = fopen("../resources/aaa.txt", "rb");
    out = fopen("../resources/aaa.txt.shaf", "wb+");

    int total;
    fseek(in, 0L, SEEK_END);
    total = ftell(in);
    fseek(in, 0L, SEEK_SET);

    printf("%d\n", total);

    fseek(in, 0, SEEK_SET);

    char *buffer = malloc(sizeof(char)*total);
    fread(buffer, sizeof(char), total, in);

    FILE *cod;
    cod = fopen("../resources/aaa.txt.cod", "rb");
    fseek(cod, 10, SEEK_SET);
    char symb = 0;
    char crt = 0;
    while(crt != '@'){
        fread(&crt, sizeof(char), 1, cod);
        if(crt == ';'){
            printf(" %c\n", symb);
            symb++;
        }else{
            printf("%c", crt);
        }
    }

//    for(int i = 0; i < 20; i++){
//        printf("%c %d  %c %d\n", buffer[i], buffer[i], buffer[i]+1, buffer[i]+1);
//    }

    return 0;
}